.. automodule:: posix1e
   :members:
   :undoc-members:

