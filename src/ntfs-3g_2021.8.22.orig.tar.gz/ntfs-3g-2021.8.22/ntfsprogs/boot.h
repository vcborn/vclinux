#ifndef _NTFS_BOOT_H_
#define _NTFS_BOOT_H_

extern const unsigned char boot_array[4136];

#endif /* _NTFS_BOOT_H_ */

