/*
  Copyright (C) 2014 Robert Kausch <robert.kausch@freac.org>
  Copyright (C) 2008 Monty <monty@xiph.org>
*/

/** analyze_cache() - analyze drive cache management.
 */
extern int analyze_cache(cdrom_drive_t *d, FILE *progress, FILE *log, int speed);
