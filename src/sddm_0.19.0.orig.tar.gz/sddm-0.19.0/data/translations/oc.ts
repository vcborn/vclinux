<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="oc">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>Clicar per vos connectar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation>%1 (Wayland)</translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>La benvenguda a %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Atencion, las majusculas son ACTIVADAS !</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Disposicion</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Fracàs de la connexion</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Connexion reüssida</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senhal</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Picatz lo nom d’utilizaire e lo senhal</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Reaviar</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Atudar</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nom d’utilizaire</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Seleccionatz vòstre nom d’utilizaire e picatz lo senhal</translation>
    </message>
</context>
</TS>
