<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Welkom bij %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Waarschuwing, Hoofdlettermodus ACTIEF!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Layout</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Inloggen</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Inloggen mislukt</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Inloggen gelukt</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Wachtwoord</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Voer je gebruikersnaam en wachtwoord in</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Herstart</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sessie</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Uitschakelen</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Gebruikersnaam</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Kies je gebruikersnaam en voer wachtwoord in</translation>
    </message>
</context>
</TS>
