<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Bem-vindo a %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Atenção, Caps Lock está ligada!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Layout</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Falha no Login</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Login bem sucedido</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Digite seu usuário e senha</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sessão</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Desligar</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Usuário</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Escolha seu usuário e entre com a senha</translation>
    </message>
</context>
</TS>
