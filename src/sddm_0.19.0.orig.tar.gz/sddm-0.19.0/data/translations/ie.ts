<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ie">
<context>
    <name>TextConstants</name>
    <message>
        <location filename="TextConstants.qml" line="30"/>
        <source>Login</source>
        <translation>Aperter</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="34"/>
        <source>Enter  username and password</source>
        <translation>Intra vor nómine de usator e contrasigne</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="31"/>
        <source>Login failed</source>
        <translation>Apertion de session ne successat</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="29"/>
        <source>Layout</source>
        <translation>Layout</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="35"/>
        <source>Select  user and enter password</source>
        <translation>Selecte li usator e intra li contrasigne</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="38"/>
        <source>Reboot</source>
        <translation>Restartar</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="32"/>
        <source>Login succeeded</source>
        <translation>Apertion de session succesosi</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="28"/>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Avise: Caps Lock es activ!</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="33"/>
        <source>Password</source>
        <translation>Contrasigne</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="39"/>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="44"/>
        <source>Welcome to %1</source>
        <translation>Benvenit a %1</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="43"/>
        <source>User name</source>
        <translation>Usator</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="40"/>
        <source>Shutdown</source>
        <translation>Extinter</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="36"/>
        <source>Enter  username</source>
        <translation>Intra vor nómine de usator</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="37"/>
        <source>Enter  password</source>
        <translation>Intra vor contrasigne</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="41"/>
        <source>Suspend</source>
        <translation>Suspender</translation>
    </message>
    <message>
        <location filename="TextConstants.qml" line="42"/>
        <source>Hibernate</source>
        <translation>Hivernar</translation>
    </message>
</context>
</TS>
