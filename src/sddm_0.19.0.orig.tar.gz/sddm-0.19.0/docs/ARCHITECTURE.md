## Introduction
SDDM consists of two main parts: the daemon (aka backend) and the greeter (aka frontend).

## Daemon
Below are the main responsibilities of the daemon.

### Application Lifecycle management
### Seat management
### Display management
### Authentication
### Power management.

## Greeter
Greeter is responsible for presenting the user interface. User interfaces are developed using the QtQuick framework. For detailed information, check out [the theming page](https://github.com/sddm/sddm/wiki/Theming).
