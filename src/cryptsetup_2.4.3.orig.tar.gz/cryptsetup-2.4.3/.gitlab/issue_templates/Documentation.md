### Documentation issue
<!-- Please, shortly describe the issue in documentation here. -->

### Additional info
<!-- Please mention what cryptsetup version you are using. -->
