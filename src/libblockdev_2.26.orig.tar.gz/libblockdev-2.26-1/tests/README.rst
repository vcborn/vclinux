See the chapter `Testing libblockdev' in the docs/ directory or on-line at
http://storaged.org/libblockdev/
