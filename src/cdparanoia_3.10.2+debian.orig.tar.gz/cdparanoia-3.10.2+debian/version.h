/******************************************************************
 * CopyPolicy: GNU Public License 2 applies
 * 
 * cdda_paranoia generation III release 10.2
 * Copyright (C) 2008 Monty monty@xiph.org
 *
 ******************************************************************/


#define VERSIONNUM "10.2"
#define VERSION "cdparanoia III release " VERSIONNUM " (September 11, 2008)\n"
