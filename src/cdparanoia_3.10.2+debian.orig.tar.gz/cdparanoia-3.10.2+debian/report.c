#include <stdio.h>
#include "interface/cdda_interface.h"

int quiet=0;
int verbose=CDDA_MESSAGE_FORGETIT;
FILE *reportfile=NULL;
