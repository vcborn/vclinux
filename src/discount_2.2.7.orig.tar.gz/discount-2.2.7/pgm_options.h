#ifndef PGM_OPTIONS_D
#define PGM_OPTIONS_D

#include <mkdio.h>

char *set_flag(mkd_flag_t *flags, char *optionstring);
void show_flags(int byname, int verbose);

#endif/*PGM_OPTIONS_D*/
