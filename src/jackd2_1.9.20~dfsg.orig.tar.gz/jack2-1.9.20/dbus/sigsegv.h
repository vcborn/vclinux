#ifndef __SIGSEGV_H__
#define __SIGSEGV_H__

#ifdef __cplusplus
extern "C"
#endif
int setup_sigsegv();

#endif
