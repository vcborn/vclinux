namespace NGraphite
{
	public enum FaceOptions
	{
		face_default = 0,
		face_dumbRendering = 1,
		face_preloadGlyphs = 2,
		face_cacheCmap = 4,
		face_preloadAll = 6	
	}
}
