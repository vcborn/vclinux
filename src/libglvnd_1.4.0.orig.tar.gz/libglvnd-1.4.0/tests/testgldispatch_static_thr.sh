#!/bin/sh

./testgldispatch -s -t

