#!/bin/sh

set -e

./testgldispatch -g -t
./testgldispatch -g -t -l

