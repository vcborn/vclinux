xlsatoms lists the interned atoms defined on an X11 server

Version 1.1 and later of xlsatoms use (and require) libxcb instead
of libX11, for less latency when communicating with the X server.

All questions regarding this software should be directed at the
Xorg mailing list:

  https://lists.x.org/mailman/listinfo/xorg

The master development code repository can be found at:

  https://gitlab.freedesktop.org/xorg/app/xlsatoms

Please submit bug reports and requests to merge patches there.

For patch submission instructions, see:

  https://www.x.org/wiki/Development/Documentation/SubmittingPatches

