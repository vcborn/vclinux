#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "locale.h"
