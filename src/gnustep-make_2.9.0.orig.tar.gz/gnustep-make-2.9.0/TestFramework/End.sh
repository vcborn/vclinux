#!/bin/sh
# This script is executed on conclusion of building/executing testcases in
# this directory.  Output from this script may be redirected to $GSTESTLOG
# in order to have it appear in the test log file.
