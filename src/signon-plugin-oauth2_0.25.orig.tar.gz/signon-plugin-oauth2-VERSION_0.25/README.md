OAuth 1.0/2.0 plugin for the SignOn daemon
==========================================

This plugin for the Accounts-SSO SignOn daemon handles the OAuth
1.0 and 2.0 authentication protocols.


License
-------

See COPYING file.


Build instructions
------------------

This project depends on Qt 5 and [signond](https://gitlab.com/accounts-sso/signond). To build it, just run
```
  qmake
  make
  make install
```