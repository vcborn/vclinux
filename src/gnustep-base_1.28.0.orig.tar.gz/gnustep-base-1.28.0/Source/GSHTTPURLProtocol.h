#ifndef	INCLUDED_GSHTTPURLPROTOCOL_H
#define	INCLUDED_GSHTTPURLPROTOCOL_H

#import "GSNativeProtocol.h"

@interface GSHTTPURLProtocol : GSNativeProtocol
@end

#endif
