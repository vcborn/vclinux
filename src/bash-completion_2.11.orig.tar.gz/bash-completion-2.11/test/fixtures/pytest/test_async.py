"""Async function pytest completion fixture."""


async def test_positive():
    pass


async def non_test_negative():
    pass


class Testing:
    async def test_positive(self):
        pass

    async def non_test_negative(self):
        pass
