aribb24
=======

A library for ARIB STD-B24, decoding JIS 8 bit characters and parsing MPEG-TS stream.
