//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main.rc
//
#define THEMENU                         102
#define APPICON                         200
#define FILE_OPEN                       40002
#define FILE_EXIT                       40003
#define HELP_ABOUT                      40004
#define FILE_SAVE                       40005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
