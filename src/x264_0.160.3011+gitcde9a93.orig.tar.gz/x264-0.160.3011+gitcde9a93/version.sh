#!/bin/sh
# Script modified from upstream source for Debian packaging since packaging
# won't include .git repository.
echo '#define X264_VERSION " r3011 cde9a93"'
echo '#define X264_POINTVER "0.160.3011 cde9a93"'
