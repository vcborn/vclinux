/*
*
*       config.h 
*
* $Id: config.h 166 2006-07-26 23:56:34Z jon $
*/

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

/* not much here for now */

#endif /* CONFIG_H_INCLUDED */
