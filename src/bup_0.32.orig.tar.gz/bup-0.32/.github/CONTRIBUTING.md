
Please see https://github.com/bup/bup/blob/master/HACKING

