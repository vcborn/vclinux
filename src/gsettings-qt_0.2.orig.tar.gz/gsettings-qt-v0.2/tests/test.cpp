#include <QtQuickTest/quicktest.h>

QUICK_TEST_MAIN(GSettings)
