struct bitmask;
hidden char *sysfs_read(char *name);
hidden int sysfs_node_read(struct bitmask *mask, char *fmt, ...);
