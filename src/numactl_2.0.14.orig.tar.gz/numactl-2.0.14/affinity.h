enum {
	NO_IO_AFFINITY = -2
};

int resolve_affinity(const char *id, struct bitmask *mask);
