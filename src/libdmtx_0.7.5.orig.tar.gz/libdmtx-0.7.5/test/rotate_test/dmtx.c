#define CALLBACK_POINT_PLOT(a,b,c,d) PlotPointCallback(a,b,c,d)
#define CALLBACK_POINT_XFRM(a,b,c,d) XfrmPlotPointCallback(a,b,c,d)
#define CALLBACK_MODULE(a,b,c,d,e)   PlotModuleCallback(a,b,c,d,e)
#define CALLBACK_MATRIX(a)           BuildMatrixCallback2(a)
#define CALLBACK_FINAL(a,b)          FinalCallback(a,b)

#include "../../dmtx.c"
