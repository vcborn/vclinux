======================================
 Welcome to pyxattr's documentation!
======================================

See the :doc:`README <readme>` for start, or the detailed :doc:`module
<module>` information.

Contents
--------

.. toctree::
   :maxdepth: 2

   readme.md
   module.rst
   news.rst

Also see the :ref:`search`.
