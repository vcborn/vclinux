# Reporting libfido2 Security Issues

To report security issues in libfido2, please contact security@yubico.com.
A PGP public key can be found at
https://www.yubico.com/support/security-advisories/issue-rating-system/.
