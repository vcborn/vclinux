#pragma once

#include <stdbool.h>

bool
libdecor_get_cursor_settings(char **theme, int *size);
