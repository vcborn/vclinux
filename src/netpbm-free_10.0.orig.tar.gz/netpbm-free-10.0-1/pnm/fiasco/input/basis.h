/*
 *  basis.h
 *
 *  Written by:		Ullrich Hafner
 *		
 *  This file is part of FIASCO (�F�ractal �I�mage �A�nd �S�equence �CO�dec)
 *  Copyright (C) 1994-2000 Ullrich Hafner <hafner@bigfoot.de>
 */

/*
 *  $Date: 2003/08/12 18:23:03 $
 *  $Author: aba-guest $
 *  $Revision: 1.1.1.1 $
 *  $State: Exp $
 */

#ifndef _BASIS_H
#define _BASIS_H

#include "wfa.h"

bool_t
get_linked_basis (const char *basis_name, wfa_t *wfa);

#endif /* not _BASIS_H */

