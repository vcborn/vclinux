/* version.h - define the current version of the package
*/

#define NETPBM_VERSION "Netpbm 10.0"
