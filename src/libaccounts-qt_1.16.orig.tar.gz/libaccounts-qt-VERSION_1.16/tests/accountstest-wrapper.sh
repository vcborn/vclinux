#!/bin/sh

exec $WRAPPER ./accountstest
